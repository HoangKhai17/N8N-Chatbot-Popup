=== N8N Chatbot Popup ===
Contributors: nguyenhoangkhai
Tags: security, privacy, chatbot
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==
Integrate the N8n Chat Widget into WordPress with full interface customization options.

== Installation ==
1. Upload plugin
2. Activate

== Changelog ==
= 1.0.0 =
- First release
