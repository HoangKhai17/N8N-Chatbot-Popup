<?php
/**
 * Plugin Name: N8N Chatbot Popup
 * Plugin URI:  https://bbotech.vn
 * Description: Integrate the N8n Chat Widget into WordPress with full interface customization options.
 * Version:     1.0.0
 * Author:      NguyenHoangKhai
 * Author URI:  https://khainguyen.link
 * License:     GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class N8n_Chat_Widget
{
    private $options;

    private $default_colors = [
        'chat--color--primary' => [
            'label'   => 'Primary color (Send button, Header)',
            'default' => '#5dd62d'
        ],
        'chat--color--primary-shade-50' => [
            'label'   => 'Primary dark color (Hover effect)',
            'default' => '#004209'
        ],
        'chat--color--primary--shade-100' => [
            'label'   => 'Primary light color (Effect)',
            'default' => '#5be625'
        ],
        'chat--color--secondary' => [
            'label'   => 'Secondary color (Icons, Links)',
            'default' => '#20b69e'
        ],
        'chat--color-secondary-shade-50' => [
            'label'   => 'Secondary dark color',
            'default' => '#1ca08a'
        ],
        'chat--color-white' => [
            'label'   => 'White text color (Text on dark background)',
            'default' => '#ffffff'
        ],
        'chat--color-dark' => [
            'label'   => 'Black text color (Text on light background)',
            'default' => '#288f00'
        ],
        'chat--color-light' => [
            'label'   => 'Chat container background color',
            'default' => '#f2f4f8'
        ],
        'chat--color-light-shade-50' => [
            'label'   => 'Bot message background color',
            'default' => '#e6e9f1'
        ],
        'chat--color-light-shade-100' => [
            'label'   => 'Header & Footer background color',
            'default' => '#c2c5cc'
        ],
    ];

    public function __construct()
    {
        add_action('admin_menu', [$this, 'add_plugin_page']);
        add_action('admin_init', [$this, 'page_init']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']); // Để load JS cho Media Uploader
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_footer', [$this, 'render_chat_widget']);
    }

    public function enqueue_admin_assets($hook)
    {
        if ($hook !== 'settings_page_n8n-chat-widget') {
            return;
        }
        wp_enqueue_media(); // Load Media Library
        wp_enqueue_script('jquery'); // Đảm bảo jQuery có sẵn
    }

    public function add_plugin_page()
    {
        add_options_page(
            'N8n Chat Widget Settings',
            'N8n Chat',
            'manage_options',
            'n8n-chat-widget',
            [$this, 'create_admin_page']
        );
    }

    public function create_admin_page()
    {
        $this->options = get_option('n8n_chat_options');
        ?>
        <div class="wrap">
            <h1>Configure the n8n Chat Widget</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('n8n_chat_option_group');
                do_settings_sections('n8n-chat-widget');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init()
    {
        register_setting(
            'n8n_chat_option_group',
            'n8n_chat_options',
            [$this, 'sanitize']
        );

        add_settings_section(
            'n8n_chat_setting_section',
            'General information',
            null,
            'n8n-chat-widget'
        );

        add_settings_field('webhook_url', 'Webhook URL (Required)', [$this, 'webhook_url_callback'], 'n8n-chat-widget', 'n8n_chat_setting_section');
        add_settings_field('chat_title', 'Title', [$this, 'chat_title_callback'], 'n8n-chat-widget', 'n8n_chat_setting_section');
        add_settings_field('bot_avatar', 'Bot Avatar', [$this, 'bot_avatar_callback'], 'n8n-chat-widget', 'n8n_chat_setting_section');

        add_settings_section(
            'n8n_chat_color_section',
            'Customize colors',
            [$this, 'color_section_info'],
            'n8n-chat-widget'
        );

        foreach ($this->default_colors as $key => $val) {
            add_settings_field(
                $key,
                $val['label'], // Dùng label tiếng Việt làm tiêu đề field
                [$this, 'color_field_callback'],
                'n8n-chat-widget',
                'n8n_chat_color_section',
                ['id' => $key, 'default' => $val]
            );
        }
    }

    public function sanitize($input)
    {
        $new_input = [];
        $new_input['webhook_url'] = isset($input['webhook_url']) ? sanitize_text_field($input['webhook_url']) : '';
        $new_input['chat_title']  = isset($input['chat_title'])  ? sanitize_text_field($input['chat_title']) : '';
        $new_input['bot_avatar']  = isset($input['bot_avatar'])  ? esc_url_raw($input['bot_avatar']) : '';

        foreach ($this->default_colors as $key => $val) {
            if (isset($input[$key])) {
                $new_input[$key] = sanitize_hex_color($input[$key]);
            }
        }

        return $new_input;
    }

    public function color_section_info()
    {
        echo '<p>Choose a color for the widget. If left blank, the default color will be used.</p>';
    }

    public function webhook_url_callback()
    {
        $value = $this->options['webhook_url'] ?? '';
        echo '<input type="text" name="n8n_chat_options[webhook_url]" value="' . esc_attr($value) . '" style="width:100%; max-width:400px;" placeholder="https://..." />';
    }

    public function chat_title_callback()
    {
        $value = $this->options['chat_title'] ?? 'AI Chatbot';
        echo '<input type="text" name="n8n_chat_options[chat_title]" value="' . esc_attr($value) . '" placeholder="AI Chatbot" />';
    }

    public function bot_avatar_callback()
    {
        $value = $this->options['bot_avatar'] ?? '';
        $preview = !empty($value) ? '<img src="' . esc_url($value) . '" style="max-width:80px; height:auto; border-radius:50%; margin-top:10px; display:block;" />' : '';

        echo '
        <input type="text" id="bot_avatar" name="n8n_chat_options[bot_avatar]" value="' . esc_attr($value) . '" style="width:300px;" />
        <button type="button" class="button" id="bot_avatar_upload">Chọn ảnh từ thư viện</button>
        <p><small>Paste URL hoặc chọn từ thư viện (PNG / SVG khuyến nghị)</small></p>
        <div id="bot_avatar_preview">' . $preview . '</div>';

        // JS để mở Media Uploader
        ?>
        <script>
            jQuery(document).ready(function($) {
                $('#bot_avatar_upload').on('click', function(e) {
                    e.preventDefault();
                    var uploader = wp.media({
                        title: 'Chọn Bot Avatar',
                        button: { text: 'Sử dụng ảnh này' },
                        multiple: false
                    }).on('select', function() {
                        var attachment = uploader.state().get('selection').first().toJSON();
                        $('#bot_avatar').val(attachment.url);
                        $('#bot_avatar_preview').html('<img src="' + attachment.url + '" style="max-width:80px; height:auto; border-radius:50%; margin-top:10px; display:block;" />');
                    }).open();
                });
            });
        </script>
        <?php
    }

    public function color_field_callback($args)
    {
        $id      = $args['id'];
        $label   = $args['default']['label'];
        $default = $args['default']['default'];
        $value   = isset($this->options[$id]) ? $this->options[$id] : $default;

        echo '<input type="color" id="' . esc_attr($id) . '" name="n8n_chat_options[' . esc_attr($id) . ']" value="' . esc_attr($value) . '" />';
        echo ' <small style="color:#888; font-family:monospace;">(' . esc_html($id) . ')</small>';
    }

    public function enqueue_assets()
    {
        $options = get_option('n8n_chat_options');
        if (empty($options['webhook_url'])) return;

        wp_enqueue_style('n8n-chat-style', plugin_dir_url(__FILE__) . 'assets/n8n.css', [], '1.0');

        $avatar = !empty($options['bot_avatar'])
            ? esc_url($options['bot_avatar'])
            : plugin_dir_url(__FILE__) . 'assets/bot-avatar.png';

        $custom_css = "
            /* BOT AVATAR - Tin nhắn */
            .chat-message.chat-message-from-bot {
                position: relative;
                padding-left: 48px !important;
            }
            .chat-message.chat-message-from-bot::before {
                content: '';
                position: absolute;
                left: 14px;
                top: 50%;
                transform: translateY(-50%);
                width: 28px;
                height: 28px;
                background-image: url('{$avatar}');
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                border-radius: 50%;
            }

            /* BOT AVATAR - Header (chat-heading) */
            .chat-heading {
                position: relative;
                display: flex;
                align-items: center;
                padding-left: 44px !important;
                gap: 12px;
            }
            .chat-heading::before {
                content: '';
                position: absolute;
                left: 0;
                top: 50%;
                transform: translateY(-50%);
                width: 34px;
                height: 34px;
                background-image: url('{$avatar}');
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                border-radius: 50%;
            }
        ";

        $custom_css .= ":root {\n";
        foreach ($this->default_colors as $key => $default) {
            $value = !empty($options[$key]) ? $options[$key] : $default['default'];
            $custom_css .= "    --{$key}: {$value};\n";
        }
        $custom_css .= "}";

        wp_add_inline_style('n8n-chat-style', $custom_css);
    }

    public function render_chat_widget()
    {
        $options = get_option('n8n_chat_options');
        if (empty($options['webhook_url'])) return;

        $webhook_url = esc_url($options['webhook_url']);
        $title = !empty($options['chat_title']) ? esc_js($options['chat_title']) : 'AI Chatbot';

        $script_url = plugin_dir_url(__FILE__) . 'assets/chat.bundle.es.js';

        echo '<div id="n8n-chat"></div>';
        ?>
        <script type="module">
            import { createChat } from '<?php echo $script_url; ?>';

            createChat({
                webhookUrl: '<?php echo $webhook_url; ?>',
                mode: 'window',
                target: '#n8n-chat',
                showWelcomeScreen: true,
                initialMessages: [
                    'How can I help you today?'
                ],
                i18n: {
                    en: {
                        title: '<?php echo $title; ?>',
                        // subtitle: 'Sẵn sàng hỗ trợ 24/7'
                    }
                },
                style: {
                    default: {
                        pixelFont: false,
                        primaryColor: ''
                    }
                }
            });
        </script>
        <?php
    }
}

new N8n_Chat_Widget();